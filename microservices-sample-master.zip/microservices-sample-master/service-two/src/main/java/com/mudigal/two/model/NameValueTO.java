package com.mudigal.two.model;

import lombok.Data;
import lombok.ToString;

/**
 * @author Vijayendra Mudigal
 */
@Data
@ToString
public class NameValueTO {

  private String name;
  private String value;

}
